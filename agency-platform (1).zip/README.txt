AGENCY PLATFORM — package layout
================================

  docs/                      every PDF the platform references (54 files) + manifest.json
  Agency Platform - V3 Ironwood Green.html   full platform, current design
  Agency Platform - V1 Indigo.html           full platform, indigo design
  Agency Platform - V2 Noir Gold.html        full platform, dark/gold design
  V1 Indigo - *.html                         one module per file, indigo design

RULE: keep every HTML file in the same folder as docs/. Each page links to
documents by relative path (docs/<file>.pdf); the PDF bytes are no longer
inside the HTML. Upload the whole folder as-is to GitHub Pages / any static
host, or open the HTML straight from disk — both work.

To add a document later: drop the PDF into docs/, then add one line to the
matching store in the HTML (FARMERS_DECS, RETAIL_DOCS, or the DEC/BINDER/
WC_INFO/COI stores in the client view):
    "policy-id": { fileName:"My-Dec.pdf", url:"docs/My-Dec.pdf" }

docs/manifest.json lists every file with its size and SHA-256 — that is the
seed for a documents table once a backend exists, at which point url: becomes
a signed link from object storage (S3 / R2 / Supabase Storage) and the folder
goes away.
